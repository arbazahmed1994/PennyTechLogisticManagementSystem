namespace WindowsFormsApplication2
{
    public class VehicleCompany
    {
        public int VehicleCompanyID { get; set; }
        public string VehicleCompanyName { get; set; }
    }
}
