
namespace WindowsFormsApplication2
{
    public class CompanyBusinessType
    {
        public int CompanyBusinessTypeID { get; set; }
        public string CompanyBusinessTypeName { get; set; }
    }
}
