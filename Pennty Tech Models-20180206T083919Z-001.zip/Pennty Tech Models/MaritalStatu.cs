
namespace WindowsFormsApplication2
{
    public class MaritalStatu
    {    
        public int MaritalStatusID { get; set; }
        public string MaritalStatusName { get; set; }
    }
}
