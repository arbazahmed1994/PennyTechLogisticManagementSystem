
namespace WindowsFormsApplication2
{
    public class Religion
    {
        public int ReligionID { get; set; }
        public string ReligionName { get; set; }
    }
}
