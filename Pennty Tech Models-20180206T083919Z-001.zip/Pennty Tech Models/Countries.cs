using System.Collections.Generic;

namespace WindowsFormsApplication2
{
    public class Country
    {
        public int CountryID { get; set; }
        public string CountryName { get; set; }
    }
}
