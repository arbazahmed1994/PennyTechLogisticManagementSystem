namespace WindowsFormsApplication2
{
    public class VehicleBusinessType
    {
    
        public int VehicleBusinessTypeID { get; set; }
        public string VehicleBusinessTypeName { get; set; }
    }
}
