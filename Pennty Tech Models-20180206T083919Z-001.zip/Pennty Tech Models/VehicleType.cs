namespace WindowsFormsApplication2
{
    public class VehicleType
    {
        public int VehicleTypeID { get; set; }
        public string VehicleTypeName { get; set; }
    }
}
