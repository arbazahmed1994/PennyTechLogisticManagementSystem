
namespace WindowsFormsApplication2
{
    public class Status
    {
        public int StatusID { get; set; }
        public string StatusName { get; set; }
    }
}
