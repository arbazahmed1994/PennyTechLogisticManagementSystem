
namespace WindowsFormsApplication2
{
    public class Color
    {    
        public int ColorID { get; set; }
        public string ColorName { get; set; }
    }
}
