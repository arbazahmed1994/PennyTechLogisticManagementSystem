
namespace WindowsFormsApplication2
{
    public class Designation
    {    
        public int DesignationID { get; set; }
        public string DesignationName { get; set; }
    }
}
