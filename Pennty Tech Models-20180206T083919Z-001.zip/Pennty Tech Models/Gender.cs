
namespace WindowsFormsApplication2
{    
    public class Gender
    {
    
        public int GenderID { get; set; }
        public string GenderName { get; set; }

    }
}
