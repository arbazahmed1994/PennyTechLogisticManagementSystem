
namespace WindowsFormsApplication2
{
    public class Driver
    {
        public string DriverCode { get; set; }
        public string DriverName { get; set; }
        public string DriverMobile { get; set; }
        public double Salary { get; set; }
        public double DailyPityCash { get; set; }
        public string DriverCNIC { get; set; }
        public string DrivingLicenceNumber { get; set; }
    }
}
