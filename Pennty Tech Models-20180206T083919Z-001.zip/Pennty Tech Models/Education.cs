
namespace WindowsFormsApplication2
{
    public class Education
    {
        public int EducationID { get; set; }
        public string EducationName { get; set; }
    }
}
